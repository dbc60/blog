---
title: A Dangerous Spectacle
date: 2016-11-09
2016: ["11"]
tags: [politics]
---

I am truly saddened by the outcome of the 2016 presidential election.
<!--more-->

I woke up this morning to find that Donald Trump is our president elect. I feel really awful about it.

Our national anthem declares America as "the land of the free and the home of the brave." While we don't always live up to that ideal, it's something we strive for. It's something we are all proud of.

We've elected as our next president a person who bullies people. He's denigrated those with disabilities. He abuses women. He spreads fear and hate based on race and religion, and wraps it in spectacle.

I hoped more people were unwilling to overlook the pain, suffering and fear he spreads and see him for what he is - a hateful, dangerous person who cares for nothing but himself. Instead, he will become our next leader. Good luck to us all.
