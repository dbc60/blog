---
title: "Begin Buildtable Template"
date: 2021-09-23T15:08:37-04:00
2021: ["09"]
---
<!--more-->

```go-html-template
{{- define "buildTable" -}}
```
