---
title: "Table Top Level Definition"
date: 2021-09-23T14:30:09-04:00
2021: ["09"]
---
<!--more-->

```go-html-template
<table class="table">
{{- template "buildTable" $data -}}
</table>
```
