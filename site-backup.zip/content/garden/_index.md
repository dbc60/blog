---
title: "Seedlings"
date: 2024-01-14T20:45:58-05:00
weight: 100
featuredImage: "/images/banners/gargoyle-overlooking-paris.jpg"
featuredImageDescription: "Gargoyle overlooking Paris"
---
