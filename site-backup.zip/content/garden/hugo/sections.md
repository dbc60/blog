---
title: "Sections"
date: 2024-12-24T04:48:23-05:00
2024: ["12"]
tags: [hugo]
---
A section is a top-level content directory, or any content directory with an _index.md file. A content directory with an _index.md file is also known as a [branch bundle](https://gohugo.io/getting-started/glossary/#branch-bundle). Section templates receive one or more page [collections](https://gohugo.io/getting-started/glossary/#collection) in [context](https://gohugo.io/getting-started/glossary/#context).
