---
title: "Partials"
date: 2024-01-14T21:34:08-05:00
2024: ["01"]
tags: [blog, draft]
draft: true
weight: 30
---

<!--more-->
{{< table_of_contents >}}
