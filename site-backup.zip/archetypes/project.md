---
title: "PROJECT: {{ dateFormat "Monday, January 2, 2006" now }}"
date: {{ .Date }}
{{ dateFormat "2006: [\"01\"]" .Date }}
tags: [project]
---

<!--more-->
{{< table_of_contents >}}
