---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
{{ dateFormat "2006: [\"01\"]" .Date }}
tags: [100DaysToOffload,draft]
draft: true
publishDate: 2021.06.01
featuredImage: "images/banners/gargoyle-overlooking-paris.jpg"
featuredImageDescription: "Gargoyle overlooking Paris"
---
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin pretium odio leo, at interdum mauris dapibus vitae. Integer vitae risus at mi pretium ornare quis vitae leo. Pellentesque sit amet malesuada lectus, quis ullamcorper erat. Maecenas gravida, lorem ac pretium eleifend, tortor metus porta felis, a fermentum nisl purus et arcu. In sed lorem accumsan, placerat sapien non, varius leo. Vivamus facilisis elementum nunc non posuere. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque sit amet consequat odio. Cras tempor euismod mattis. Fusce dictum congue orci, non iaculis urna molestie id. Vivamus lobortis massa eget purus vulputate, ut malesuada tortor faucibus.

{{< days 1 >}}
