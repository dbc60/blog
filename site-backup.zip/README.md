This is the code that enables some static site generate to build [my blog](http://douglascuthbertson.com/). The HTML templates, CSS files, and other files that define its structure, look, and feel are licensed under [Creative Commons by Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).

All content, unless otherwise specified, is Copyright (c) 2015-2021, Douglas Cuthbertson.
